import cdmsapp
from cdmsapp.extensions import db

application = cdmsapp.create_app()

if __name__ == '__main__':
    application.run()

# develop a html code to create color changing carousel



