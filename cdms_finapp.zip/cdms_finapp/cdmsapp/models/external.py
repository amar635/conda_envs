class pincodeModel():
    searchby = "pincode"
    value = 0
